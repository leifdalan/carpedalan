--
-- PostgreSQL database dump
--

-- Dumped from database version 10.0
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

--
-- Name: carpe_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carpe_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


--
-- Name: carpe_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.carpe_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: carpe_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.carpe_migrations_id_seq OWNED BY public.carpe_migrations.id;


--
-- Name: carpe_migrations_lock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carpe_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


--
-- Name: carpe_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.carpe_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: carpe_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.carpe_migrations_lock_index_seq OWNED BY public.carpe_migrations_lock.index;


--
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


--
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- Name: photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.photos (
    id uuid DEFAULT public.uuid_generate_v1mc() NOT NULL,
    "timestamp" integer,
    date date,
    "originalUrl" character varying(255),
    description character varying(255),
    etag character varying(255),
    key character varying(255),
    status text DEFAULT 'active'::text,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "apertureValue" character varying(255),
    "brightnessValue" character varying(255),
    "colorSpace" character varying(255),
    contrast character varying(255),
    "createDate" character varying(255),
    "customRendered" character varying(255),
    "dateTimeOriginal" character varying(255),
    "digitalZoomRatio" character varying(255),
    "exifImageHeight" character varying(255),
    "exifImageWidth" character varying(255),
    "exposureCompensation" character varying(255),
    "exposureMode" character varying(255),
    "exposureProgram" character varying(255),
    "exposureTime" character varying(255),
    flash character varying(255),
    "fNumber" character varying(255),
    "focalLength" character varying(255),
    "focalLengthIn35mmFormat" character varying(255),
    "gpsAltitude" character varying(255),
    "gpsAltitudeRef" character varying(255),
    "gpsDateStamp" character varying(255),
    "gpsDOP" character varying(255),
    "gpsLatitude" character varying(255),
    "gpsLatitudeRef" character varying(255),
    "gpsLongitude" character varying(255),
    "gpsLongitudeRef" character varying(255),
    "gpsTimeStamp" character varying(255),
    "gpsVersionID" character varying(255),
    "imageHeight" character varying(255),
    "imageWidth" character varying(255),
    "interopIndex" character varying(255),
    "ISO" character varying(255),
    make character varying(255),
    "maxApertureValue" character varying(255),
    "meteringMode" character varying(255),
    model character varying(255),
    "modifyDate" character varying(255),
    orientation character varying(255),
    "resolutionUnit" character varying(255),
    saturation character varying(255),
    "sceneCaptureType" character varying(255),
    "sensingMethod" character varying(255),
    sharpness character varying(255),
    "shutterSpeedValue" character varying(255),
    software character varying(255),
    "subjectDistance" character varying(255),
    "subjectDistanceRange" character varying(255),
    "subSecTime" character varying(255),
    "subSecTimeDigitized" character varying(255),
    "subSecTimeOriginal" character varying(255),
    "whiteBalance" character varying(255),
    "xResolution" character varying(255),
    "yCbCrPositioning" character varying(255),
    "yResolution" character varying(255),
    "isPending" boolean DEFAULT false,
    CONSTRAINT photos_status_check CHECK ((status = ANY (ARRAY['active'::text, 'deleted'::text])))
);


--
-- Name: photos_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.photos_tags (
    id uuid DEFAULT public.uuid_generate_v1mc() NOT NULL,
    "photoId" uuid,
    "tagId" uuid,
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id uuid DEFAULT public.uuid_generate_v1mc() NOT NULL,
    name character varying(255),
    "createdAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: carpe_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carpe_migrations ALTER COLUMN id SET DEFAULT nextval('public.carpe_migrations_id_seq'::regclass);


--
-- Name: carpe_migrations_lock index; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carpe_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.carpe_migrations_lock_index_seq'::regclass);


--
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- Data for Name: carpe_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carpe_migrations (id, name, batch, migration_time) FROM stdin;
1	20181109100714_session.js	1	2020-03-03 07:34:56.185+00
2	20181109154743_photos.js	1	2020-03-03 07:34:56.262+00
3	20181109163403_tags.js	1	2020-03-03 07:34:56.272+00
4	20181109165111_photos_tags.js	1	2020-03-03 07:34:56.293+00
5	20190124224148_remove_unwanted_tags.js	1	2020-03-03 07:34:56.337+00
6	20190201163411_add_status_enum.js	1	2020-03-03 07:34:56.35+00
7	20190201224849_set_pending_for_invalids.js	1	2020-03-03 07:34:56.358+00
\.


--
-- Data for Name: carpe_migrations_lock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carpe_migrations_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations (id, name, batch, migration_time) FROM stdin;
1	20181108211614_setup.js	1	2020-03-03 07:34:54.602+00
\.


--
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Data for Name: photos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.photos (id, "timestamp", date, "originalUrl", description, etag, key, status, "createdAt", "updatedAt", "apertureValue", "brightnessValue", "colorSpace", contrast, "createDate", "customRendered", "dateTimeOriginal", "digitalZoomRatio", "exifImageHeight", "exifImageWidth", "exposureCompensation", "exposureMode", "exposureProgram", "exposureTime", flash, "fNumber", "focalLength", "focalLengthIn35mmFormat", "gpsAltitude", "gpsAltitudeRef", "gpsDateStamp", "gpsDOP", "gpsLatitude", "gpsLatitudeRef", "gpsLongitude", "gpsLongitudeRef", "gpsTimeStamp", "gpsVersionID", "imageHeight", "imageWidth", "interopIndex", "ISO", make, "maxApertureValue", "meteringMode", model, "modifyDate", orientation, "resolutionUnit", saturation, "sceneCaptureType", "sensingMethod", sharpness, "shutterSpeedValue", software, "subjectDistance", "subjectDistanceRange", "subSecTime", "subSecTimeDigitized", "subSecTimeOriginal", "whiteBalance", "xResolution", "yCbCrPositioning", "yResolution", "isPending") FROM stdin;
8bb52cfa-5d21-11ea-82b3-eb1e2392c159	1577096056	\N	\N		\N	original/IMG_20191223_101416_MP~2.jpg	active	2020-03-03 07:35:24.732738+00	2020-03-03 07:35:24.732738+00	\N	\N	\N	\N	\N	\N	1577096056	\N	4032	3024	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	4032	3024	\N	\N	\N	\N	\N	\N	1578343983	\N	2	\N	\N	\N	\N	\N	Google	\N	\N	\N	\N	\N	\N	72	\N	72	f
97a9e514-5d21-11ea-82b3-a316669e27b5	1577864668	\N	\N		\N	original/IMG_20200101_074428_MP.jpg	active	2020-03-03 07:35:44.794084+00	2020-03-03 07:35:44.794084+00	1.58	-0.87	1	\N	1577864668	1	1577864668	\N	3024	4032	\N	\N	2	0.041671	16	1.73	4.38	27	6.69	\N	2020:01:01	17.088	47.69482222222222	N	-122.27975277777777	W	{"15","44","28"}	{"2","2","0","0"}	3024	4032	R98	410	Google	1.58	2	Pixel 4	1577864668	1	2	\N	\N	2	\N	4.58	HDR+ 1.0.281780091zdh	1.206	2	841017	841017	841017	\N	72	1	72	f
a22a777e-5d21-11ea-82b3-df58a7587943	1577865257	\N	\N		\N	original/IMG_20200101_075417_MP.jpg	active	2020-03-03 07:36:02.415063+00	2020-03-03 07:36:02.415063+00	1.58	-0.45	1	\N	1577865257	1	1577865257	\N	3024	4032	\N	\N	2	0.025011	16	1.73	4.38	27	6.69	\N	2020:01:01	17.088	47.69482222222222	N	-122.27975277777777	W	{"15","54","17"}	{"2","2","0","0"}	3024	4032	R98	510	Google	1.58	2	Pixel 4	1577865257	1	2	\N	\N	2	\N	5.32	HDR+ 1.0.281780091zdh	0.488	1	225854	225854	225854	\N	72	1	72	f
acb6b19e-5d21-11ea-82b3-63b674ee51db	1577865365	\N	\N		\N	original/IMG_20200101_075605_MP.jpg	active	2020-03-03 07:36:20.11289+00	2020-03-03 07:36:20.11289+00	1.58	-0.65	1	\N	1577865365	1	1577865365	\N	3024	4032	\N	\N	2	0.041671	16	1.73	4.38	27	6.69	\N	2020:01:01	17.088	47.69482222222222	N	-122.27975277777777	W	{"15","56","5"}	{"2","2","0","0"}	3024	4032	R98	351	Google	1.58	2	Pixel 4	1577865365	1	2	\N	\N	2	\N	4.58	HDR+ 1.0.281780091zdh	1.4	2	337051	337051	337051	\N	72	1	72	f
b8def3c8-5d21-11ea-82b3-730610dfc534	1577878294	\N	\N		\N	original/IMG_20200101_113134_MP.jpg	active	2020-03-03 07:36:40.509696+00	2020-03-03 07:36:40.509696+00	1.58	5.89	1	\N	1577878294	1	1577878294	\N	3024	4032	\N	\N	2	0.002983	16	1.73	4.38	27	6.69	\N	2020:01:01	31.597	47.69495	N	-122.27980555555555	W	{"19","31","22"}	{"2","2","0","0"}	3024	4032	R98	53	Google	1.58	2	Pixel 4	1577878294	1	2	\N	\N	2	\N	8.39	HDR+ 1.0.281780091zdh	1.018	2	915522	915522	915522	\N	72	1	72	f
c3d62ff8-5d21-11ea-82b3-575054c4d192	1577879117	\N	\N		\N	original/IMG_20200101_114517_MP.jpg	active	2020-03-03 07:36:58.908168+00	2020-03-03 07:36:58.908168+00	2	7.45	1	\N	1577879117	1	1577879117	\N	2448	3264	\N	\N	2	0.001304	16	2	2.47	21	16.19	\N	2020:01:01	27.309	47.69693333333333	N	-122.27293333333333	W	{"19","43","30"}	{"2","2","0","0"}	2448	3264	R98	55	Google	2	2	Pixel 4	1577879117	1	2	\N	\N	2	\N	9.58	HDR+ 1.0.281780091zdh	0.43	1	650303	650303	650303	\N	72	1	72	f
cf6cbfbc-5d21-11ea-82b3-175ddebe6301	1577879236	\N	\N		\N	original/IMG_20200101_114716_MP.jpg	active	2020-03-03 07:37:18.349304+00	2020-03-03 07:37:18.349304+00	1.58	7.57	1	\N	1577879236	1	1577879236	\N	3024	4032	\N	\N	2	0.00081	16	1.73	4.38	27	23.46	1	2020:01:01	6.796	47.69693333333333	N	-122.27289166666667	W	{"19","47","16"}	{"2","2","0","0"}	3024	4032	R98	61	Google	1.58	2	Pixel 4	1577879236	1	2	\N	\N	2	\N	10.27	HDR+ 1.0.281780091zdh	3.034	3	218837	218837	218837	\N	72	1	72	f
daf65e9c-5d21-11ea-82b3-c7a347e3c2f5	1577879935	\N	\N		\N	original/IMG_20200101_115855_MP.jpg	active	2020-03-03 07:37:37.704575+00	2020-03-03 07:37:37.704575+00	1.58	7.93	1	\N	1577879935	1	1577879935	\N	3024	4032	\N	\N	2	0.000554	16	1.73	4.38	27	4.9	1	2020:01:01	4.045	47.69685277777778	N	-122.27286388888889	W	{"19","58","55"}	{"2","2","0","0"}	3024	4032	R98	69	Google	1.58	2	Pixel 4	1577879935	1	2	\N	\N	2	\N	10.82	HDR+ 1.0.281780091zdh	0.88	1	456218	456218	456218	\N	72	1	72	f
e55c38c0-5d21-11ea-82b3-abde5bc879fc	1577880153	\N	\N		\N	original/IMG_20200101_120233_MP.jpg	active	2020-03-03 07:37:55.150392+00	2020-03-03 07:37:55.150392+00	1.58	8.08	1	\N	1577880153	1	1577880153	\N	3024	4032	\N	\N	2	0.000426	16	1.73	4.38	27	4.9	1	2020:01:01	32.72	47.69685277777778	N	-122.27286388888889	W	{"19","59","12"}	{"2","2","0","0"}	3024	4032	R98	81	Google	1.58	2	Pixel 4	1577880153	1	2	\N	\N	2	\N	11.2	HDR+ 1.0.281780091zdh	2.716	2	177076	177076	177076	\N	72	1	72	f
f05ad8e4-5d21-11ea-82b3-5f8cb1d50bb4	1577880603	\N	\N		\N	original/IMG_20200101_121003_MP.jpg	active	2020-03-03 07:38:13.595266+00	2020-03-03 07:38:13.595266+00	1.58	8.37	1	\N	1577880603	1	1577880603	\N	3024	4032	\N	\N	2	0.000341	16	1.73	4.38	27	\N	1	2020:01:01	50.003	47.69716944444444	N	-122.273225	W	{"20","7","34"}	{"2","2","0","0"}	3024	4032	R98	83	Google	1.58	2	Pixel 4	1577880603	1	2	\N	\N	2	\N	11.52	HDR+ 1.0.281780091zdh	1.059	2	111755	111755	111755	\N	72	1	72	f
fb0257ae-5d21-11ea-82b3-67d307ae481e	1577880671	\N	\N		\N	original/IMG_20200101_121111_MP.jpg	active	2020-03-03 07:38:31.472336+00	2020-03-03 07:38:31.472336+00	1.58	6.25	1	\N	1577880671	1	1577880671	\N	3024	4032	\N	\N	2	0.002088	16	1.73	4.38	27	\N	1	2020:01:01	94.541	47.69893333333333	N	-122.2674611111111	W	{"20","10","12"}	{"2","2","0","0"}	3024	4032	R98	59	Google	1.58	2	Pixel 4	1577880671	1	2	\N	\N	2	\N	8.9	HDR+ 1.0.281780091zdh	0.56	1	429781	429781	429781	\N	72	1	72	f
062213d6-5d22-11ea-82b3-6f903013339a	1577880734	\N	\N		\N	original/IMG_20200101_121214_MP.jpg	active	2020-03-03 07:38:50.122925+00	2020-03-03 07:38:50.122925+00	1.58	6.94	1	\N	1577880734	1	1577880734	\N	3024	4032	\N	\N	2	0.001491	16	1.73	4.38	27	3.67	\N	2020:01:01	35.411	47.69690833333333	N	-122.27275555555555	W	{"20","11","29"}	{"2","2","0","0"}	3024	4032	R98	51	Google	1.58	2	Pixel 4	1577880734	1	2	\N	\N	2	\N	9.39	HDR+ 1.0.281780091zdh	0.825	1	692884	692884	692884	\N	72	1	72	f
10fcf492-5d22-11ea-82b3-7783dd16cfdb	1577893676	\N	\N		\N	original/IMG_20200101_154756_MP.jpg	active	2020-03-03 07:39:08.345649+00	2020-03-03 07:39:08.345649+00	1.58	-3.41	1	\N	1577893676	1	1577893676	\N	3024	4032	\N	\N	2	0.050023	16	1.73	4.38	27	6.69	\N	2020:01:01	17.204	47.69478055555555	N	-122.279625	W	{"23","47","56"}	{"2","2","0","0"}	3024	4032	R98	1988	Google	1.58	2	Pixel 4	1577893676	1	2	\N	\N	2	\N	4.32	HDR+ 1.0.281780091zdh	0.516	1	109181	109181	109181	\N	72	1	72	f
1cb32cf2-5d22-11ea-82b3-237ea6b87ea4	1577949455	\N	\N		\N	original/IMG_20200102_071735_MP.jpg	active	2020-03-03 07:39:27.996286+00	2020-03-03 07:39:27.996286+00	1.58	-0.42	1	\N	1577949455	1	1577949455	\N	3024	4032	\N	\N	2	0.041671	16	1.73	4.38	27	6.69	\N	2020:01:02	23.648	47.69475555555555	N	-122.27963055555556	W	{"15","17","35"}	{"2","2","0","0"}	3024	4032	R98	301	Google	1.58	2	Pixel 4	1577949455	6	2	\N	\N	2	\N	4.58	HDR+ 1.0.281780091zdh	0.852	1	563379	563379	563379	\N	72	1	72	f
29992548-5d22-11ea-82b3-7f93d787d466	1577953514	\N	\N		\N	original/IMG_20200102_082513_1_MP.jpg	active	2020-03-03 07:39:49.624923+00	2020-03-03 07:39:49.624923+00	1.58	2.81	1	\N	1577953514	1	1577953514	\N	3024	4032	\N	\N	2	0.01666	16	1.73	4.38	27	23.3	\N	2020:01:02	19.43	47.72240277777778	N	-122.2979	W	{"16","25","14"}	{"2","2","0","0"}	3024	4032	R98	80	Google	1.58	2	Pixel 4	1577953514	6	2	\N	\N	2	\N	5.91	HDR+ 1.0.281780091zdh	0.776	1	055804	055804	055804	\N	72	1	72	f
3596ad7a-5d22-11ea-82b3-b33164fa16e8	1577953541	\N	\N		\N	original/IMG_20200102_082541_MP.jpg	active	2020-03-03 07:40:09.743037+00	2020-03-03 07:40:09.743037+00	1.58	2.1	1	\N	1577953541	1	1577953541	\N	3024	4032	\N	\N	2	0.025011	16	1.73	4.38	27	23.3	\N	2020:01:02	19.43	47.72240277777778	N	-122.2979	W	{"16","25","14"}	{"2","2","0","0"}	3024	4032	R98	87	Google	1.58	2	Pixel 4	1577953541	6	2	\N	\N	2	\N	5.32	HDR+ 1.0.281780091zdh	1.264	2	413675	413675	413675	\N	72	1	72	f
40f8295a-5d22-11ea-82b3-f372de3e3a53	1577955588	\N	\N		\N	original/IMG_20200102_085948_MP.jpg	active	2020-03-03 07:40:28.846617+00	2020-03-03 07:40:28.846617+00	1.58	-0.21	1	\N	1577955588	1	1577955588	\N	3024	4032	\N	\N	2	0.01666	16	1.73	4.38	27	6.69	\N	2020:01:02	23.042	47.69472777777777	N	-122.27978055555556	W	{"16","59","48"}	{"2","2","0","0"}	3024	4032	R98	649	Google	1.58	2	Pixel 4	1577955588	1	2	\N	\N	2	\N	5.91	HDR+ 1.0.281780091zdh	0.388	1	564427	564427	564427	\N	72	1	72	f
4bfa8668-5d22-11ea-82b3-bf34bb9dcaec	1577955594	\N	\N		\N	original/IMG_20200102_085954_MP.jpg	active	2020-03-03 07:40:47.310209+00	2020-03-03 07:40:47.310209+00	1.58	-0.22	1	\N	1577955594	1	1577955594	\N	3024	4032	\N	\N	2	0.025011	16	1.73	4.38	27	6.69	\N	2020:01:02	23.042	47.69472777777777	N	-122.27978055555556	W	{"16","59","53"}	{"2","2","0","0"}	3024	4032	R98	435	Google	1.58	2	Pixel 4	1577955594	1	2	\N	\N	2	\N	5.32	HDR+ 1.0.281780091zdh	0.399	1	173807	173807	173807	\N	72	1	72	f
57a727a0-5d22-11ea-82b3-4b2f694f5aaf	1577994043	\N	\N		\N	original/IMG_20200102_194043.jpg	active	2020-03-03 07:41:06.90253+00	2020-03-03 07:41:06.90253+00	1.7	-2.61	1	\N	1577994043	1	1577994043	\N	3024	4032	\N	\N	2	0.051983	16	1.8	4.44	27	6.69	\N	2020:01:03	16	47.69474722222222	N	-122.27974166666667	W	{"3","40","43"}	{"2","2","0","0"}	3024	4032	R98	1188	Google	1.7	2	Pixel 3	1577994043	1	2	\N	\N	2	\N	4.27	HDR+ 1.0.281780091zdh	0.831	1	489376	489376	489376	\N	72	1	72	f
623d47ee-5d22-11ea-82b3-e3b1aa921a42	1578036340	\N	\N		\N	original/IMG_20200103_072540_MP.jpg	active	2020-03-03 07:41:24.66427+00	2020-03-03 07:41:24.66427+00	1.58	-1.46	1	\N	1578036340	1	1578036340	\N	3024	4032	\N	\N	2	0.041671	16	1.73	4.38	27	6.69	\N	2020:01:03	17.555	47.69475277777777	N	-122.27977777777778	W	{"15","25","40"}	{"2","2","0","0"}	3024	4032	R98	619	Google	1.58	2	Pixel 4	1578036340	3	2	\N	\N	2	\N	4.58	HDR+ 1.0.281780091zdh	0.694	1	822426	822426	822426	\N	72	1	72	f
6d9af1f4-5d22-11ea-82b3-cb2c0ef45bd4	1578036362	\N	\N		\N	original/IMG_20200103_072602_MP.jpg	active	2020-03-03 07:41:43.714152+00	2020-03-03 07:41:43.714152+00	1.58	-1.5	1	\N	1578036362	1	1578036362	\N	3024	4032	\N	\N	2	0.041671	16	1.73	4.38	27	6.69	\N	2020:01:03	17.555	47.69475277777777	N	-122.27977777777778	W	{"15","26","1"}	{"2","2","0","0"}	3024	4032	R98	636	Google	1.58	2	Pixel 4	1578036362	1	2	\N	\N	2	\N	4.58	HDR+ 1.0.281780091zdh	0.56	1	238639	238639	238639	\N	72	1	72	f
7992a470-5d22-11ea-82b3-3f05f3dd161a	1578047083	\N	\N		\N	original/IMG_20200103_102443_MP.jpg	active	2020-03-03 07:42:03.81184+00	2020-03-03 07:42:03.81184+00	1.58	2.92	1	\N	1578047083	1	1578047083	\N	3024	4032	\N	\N	2	0.01666	16	1.73	4.38	27	6.69	\N	2020:01:03	50.036	47.69476944444444	N	-122.27972777777778	W	{"18","24","40"}	{"2","2","0","0"}	3024	4032	R98	74	Google	1.58	2	Pixel 4	1578047083	1	2	\N	\N	2	\N	5.91	HDR+ 1.0.281780091zdh	0.537	1	508731	508731	508731	\N	72	1	72	f
84fb465a-5d22-11ea-82b3-1fd3eb9389c5	1578132855	\N	\N		\N	original/IMG_20200104_101415_MP.jpg	active	2020-03-03 07:42:22.951347+00	2020-03-03 07:42:22.951347+00	1.58	2.46	1	\N	1578132855	1	1578132855	\N	3024	4032	\N	\N	2	0.033363	16	1.73	4.38	27	5.8	1	2020:01:04	17.307	47.666891666666665	N	-122.30092222222223	W	{"18","4","48"}	{"2","2","0","0"}	3024	4032	R98	51	Google	1.58	2	Pixel 4	1578132855	1	2	\N	\N	2	\N	4.91	HDR+ 1.0.281780091zdh	1.104	2	543892	543892	543892	\N	72	1	72	f
906e7656-5d22-11ea-82b3-8bec0ac2ad97	1578134208	\N	\N		\N	original/IMG_20200104_103648.jpg	active	2020-03-03 07:42:42.156134+00	2020-03-03 07:42:42.156134+00	1.7	1.55	1	\N	1578134208	1	1578134208	\N	3024	4032	\N	\N	2	0.041667	16	1.8	4.44	27	6.3	1	2020:01:04	22.86	47.66691111111111	N	-122.30096666666667	W	{"18","34","20"}	{"2","2","0","0"}	3024	4032	R98	83	Google	1.7	2	Pixel 3	1578134208	1	2	\N	\N	2	\N	4.58	HDR+ 1.0.281780091zdh	0.56	1	539351	539351	539351	\N	72	1	72	f
9bdab9fa-5d22-11ea-82b3-db81d8ce2865	1578139203	\N	\N		\N	original/IMG_20200104_120003_MP.jpg	active	2020-03-03 07:43:01.323504+00	2020-03-03 07:43:01.323504+00	1.58	1.53	1	\N	1578139203	1	1578139203	\N	3024	4032	\N	\N	2	0.042012	16	1.73	4.38	27	6.69	\N	2020:01:04	17.466	47.69474722222222	N	-122.27976111111111	W	{"20","0","3"}	{"2","2","0","0"}	3024	4032	R98	77	Google	1.58	2	Pixel 4	1578139203	1	2	\N	\N	2	\N	4.57	HDR+ 1.0.281780091zdh	1.329	2	376088	376088	376088	\N	72	1	72	f
a7f55cd6-5d22-11ea-82b3-e3ef22e90440	1578143605	\N	\N		\N	original/IMG_20200104_131325.jpg	active	2020-03-03 07:43:21.629063+00	2020-03-03 07:43:21.629063+00	1.7	1.69	1	\N	1578143605	1	1578143605	\N	3024	4032	\N	\N	2	0.016149	16	1.8	4.44	27	6.69	\N	2020:01:04	24.251	47.694691666666664	N	-122.27967222222222	W	{"21","10","38"}	{"2","2","0","0"}	3024	4032	R98	194	Google	1.7	2	Pixel 3	1578143605	1	2	\N	\N	2	\N	5.95	HDR+ 1.0.281780091zdh	0.831	1	142914	142914	142914	\N	72	1	72	f
b30ed5ca-5d22-11ea-82b3-df588589fc18	1578160475	\N	\N		\N	original/IMG_20200104_175435_MP.jpg	active	2020-03-03 07:43:40.255394+00	2020-03-03 07:43:40.255394+00	1.58	-0.77	1	\N	1578160475	1	1578160475	\N	3024	4032	\N	\N	2	0.041671	16	1.73	4.38	27	6.69	\N	2020:01:05	17.617	47.69478611111111	N	-122.27971111111111	W	{"1","54","35"}	{"2","2","0","0"}	3024	4032	R98	382	Google	1.58	2	Pixel 4	1578160475	1	2	\N	\N	2	\N	4.58	HDR+ 1.0.281780091zdh	0.326	1	302105	302105	302105	\N	72	1	72	f
be2645e2-5d22-11ea-82b3-2f8738158484	1578160477	\N	\N		\N	original/IMG_20200104_175437_MP.jpg	active	2020-03-03 07:43:58.863482+00	2020-03-03 07:43:58.863482+00	1.58	-0.62	1	\N	1578160477	1	1578160477	\N	3024	4032	\N	\N	2	0.041671	16	1.73	4.38	27	6.69	\N	2020:01:05	17.617	47.69478611111111	N	-122.27971111111111	W	{"1","54","36"}	{"2","2","0","0"}	3024	4032	R98	346	Google	1.58	2	Pixel 4	1578160477	1	2	\N	\N	2	\N	4.58	HDR+ 1.0.281780091zdh	0.326	1	388816	388816	388816	\N	72	1	72	f
ce709d26-5d22-11ea-82b3-c735875b51d4	1578161955	\N	\N		\N	original/IMG_20200104_181915_MP.jpg	active	2020-03-03 07:44:26.190748+00	2020-03-03 07:44:26.190748+00	1.58	-0.61	1	\N	1578161955	1	1578161955	\N	3024	4032	\N	\N	2	0.041671	16	1.73	4.38	27	6.69	\N	2020:01:05	31.119	47.694824999999994	N	-122.27950555555556	W	{"2","19","14"}	{"2","2","0","0"}	3024	4032	R98	343	Google	1.58	2	Pixel 4	1578161955	1	2	\N	\N	2	\N	4.58	HDR+ 1.0.281780091zdh	0.488	1	814467	814467	814467	\N	72	1	72	f
dde81284-5d22-11ea-82b3-436e517d6d70	1578161956	\N	\N		\N	original/IMG_20200104_181916_MP.jpg	active	2020-03-03 07:44:52.140613+00	2020-03-03 07:44:52.140613+00	1.58	-0.67	1	\N	1578161956	1	1578161956	\N	3024	4032	\N	\N	2	0.033363	16	1.73	4.38	27	6.69	\N	2020:01:05	31.119	47.694824999999994	N	-122.27950555555556	W	{"2","19","16"}	{"2","2","0","0"}	3024	4032	R98	445	Google	1.58	2	Pixel 4	1578161956	1	2	\N	\N	2	\N	4.91	HDR+ 1.0.281780091zdh	0.488	1	538717	538717	538717	\N	72	1	72	f
ea11025a-5d22-11ea-82b3-4fc3e0c54b7f	1578162279	\N	\N		\N	original/IMG_20200104_182439_MP.jpg	active	2020-03-03 07:45:12.54491+00	2020-03-03 07:45:12.54491+00	1.58	-0.58	1	\N	1578162279	1	1578162279	\N	3024	4032	\N	\N	2	0.008351	16	1.73	4.38	27	6.69	\N	2020:01:05	17.204	47.694741666666665	N	-122.27974166666667	W	{"2","24","39"}	{"2","2","0","0"}	3024	4032	R98	1679	Google	1.58	2	Pixel 4	1578162279	6	2	\N	\N	2	\N	6.9	HDR+ 1.0.281780091zdh	0.516	1	522717	522717	522717	\N	72	1	72	f
f99f80ca-5d22-11ea-82b3-db9345c94151	1578162297	\N	\N		\N	original/IMG_20200104_182456_MP.jpg	active	2020-03-03 07:45:38.644008+00	2020-03-03 07:45:38.644008+00	1.58	-1.16	1	\N	1578162297	1	1578162297	\N	3024	4032	\N	\N	2	0.01666	16	1.73	4.38	27	6.69	\N	2020:01:05	17.204	47.694741666666665	N	-122.27974166666667	W	{"2","24","56"}	{"2","2","0","0"}	3024	4032	R98	1258	Google	1.58	2	Pixel 4	1578162297	6	2	\N	\N	2	\N	5.91	HDR+ 1.0.281780091zdh	0.549	1	011816	011816	011816	\N	72	1	72	f
\.


--
-- Data for Name: photos_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.photos_tags (id, "photoId", "tagId", "createdAt", "updatedAt") FROM stdin;
4dc379a6-615e-11ea-b023-232de92e63ff	57a727a0-5d22-11ea-82b3-4b2f694f5aaf	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc39bde-615e-11ea-b023-1b32e42bf996	4bfa8668-5d22-11ea-82b3-bf34bb9dcaec	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc39e54-615e-11ea-b023-03934eb26787	40f8295a-5d22-11ea-82b3-f372de3e3a53	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3a084-615e-11ea-b023-6320aabb7533	3596ad7a-5d22-11ea-82b3-b33164fa16e8	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3a2b4-615e-11ea-b023-3faaf6a7bed6	29992548-5d22-11ea-82b3-7f93d787d466	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3bb78-615e-11ea-b023-5b7c7a9ae229	1cb32cf2-5d22-11ea-82b3-237ea6b87ea4	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3bde4-615e-11ea-b023-279e9fd49f9a	10fcf492-5d22-11ea-82b3-7783dd16cfdb	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3c028-615e-11ea-b023-7b2ed7faa762	062213d6-5d22-11ea-82b3-6f903013339a	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3c280-615e-11ea-b023-4317704944dd	fb0257ae-5d21-11ea-82b3-67d307ae481e	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3c4a6-615e-11ea-b023-03e9cedd6a43	f05ad8e4-5d21-11ea-82b3-5f8cb1d50bb4	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3c71c-615e-11ea-b023-8bd397349c3d	e55c38c0-5d21-11ea-82b3-abde5bc879fc	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3c8b6-615e-11ea-b023-53d6fbca4379	daf65e9c-5d21-11ea-82b3-c7a347e3c2f5	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3ce24-615e-11ea-b023-9f0a7d9535e5	cf6cbfbc-5d21-11ea-82b3-175ddebe6301	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3d19e-615e-11ea-b023-b366735332d6	c3d62ff8-5d21-11ea-82b3-575054c4d192	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3d3ba-615e-11ea-b023-a31980838906	b8def3c8-5d21-11ea-82b3-730610dfc534	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3d5fe-615e-11ea-b023-4b4af3426da9	acb6b19e-5d21-11ea-82b3-63b674ee51db	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3d7f2-615e-11ea-b023-d338568df857	a22a777e-5d21-11ea-82b3-df58a7587943	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3da90-615e-11ea-b023-3bc491dab925	97a9e514-5d21-11ea-82b3-a316669e27b5	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
4dc3dc5c-615e-11ea-b023-df0e9061a4a3	8bb52cfa-5d21-11ea-82b3-eb1e2392c159	96ca9d70-615c-11ea-96ff-17ea76b94605	2020-03-08 17:00:24.744602+00	2020-03-08 17:00:24.744602+00
75aa5b92-615e-11ea-b023-cb89adbd404c	f99f80ca-5d22-11ea-82b3-db9345c94151	aa22cd8e-615c-11ea-96ff-1782b564d1de	2020-03-08 17:01:31.694332+00	2020-03-08 17:01:31.694332+00
75aa5dfe-615e-11ea-b023-dbd788c78916	ea11025a-5d22-11ea-82b3-4fc3e0c54b7f	aa22cd8e-615c-11ea-96ff-1782b564d1de	2020-03-08 17:01:31.694332+00	2020-03-08 17:01:31.694332+00
75aa60e2-615e-11ea-b023-674d0efb18c4	dde81284-5d22-11ea-82b3-436e517d6d70	aa22cd8e-615c-11ea-96ff-1782b564d1de	2020-03-08 17:01:31.694332+00	2020-03-08 17:01:31.694332+00
75aa742e-615e-11ea-b023-af02a0d53bca	ce709d26-5d22-11ea-82b3-c735875b51d4	aa22cd8e-615c-11ea-96ff-1782b564d1de	2020-03-08 17:01:31.694332+00	2020-03-08 17:01:31.694332+00
75aa774e-615e-11ea-b023-f3488b5fafa0	be2645e2-5d22-11ea-82b3-2f8738158484	aa22cd8e-615c-11ea-96ff-1782b564d1de	2020-03-08 17:01:31.694332+00	2020-03-08 17:01:31.694332+00
75aa78fc-615e-11ea-b023-c7f8f9627ca1	b30ed5ca-5d22-11ea-82b3-df588589fc18	aa22cd8e-615c-11ea-96ff-1782b564d1de	2020-03-08 17:01:31.694332+00	2020-03-08 17:01:31.694332+00
75aa7a6e-615e-11ea-b023-4b3b8c5379ef	a7f55cd6-5d22-11ea-82b3-e3ef22e90440	aa22cd8e-615c-11ea-96ff-1782b564d1de	2020-03-08 17:01:31.694332+00	2020-03-08 17:01:31.694332+00
75aa7dac-615e-11ea-b023-9b3e0bfe1294	9bdab9fa-5d22-11ea-82b3-db81d8ce2865	aa22cd8e-615c-11ea-96ff-1782b564d1de	2020-03-08 17:01:31.694332+00	2020-03-08 17:01:31.694332+00
75aa7fe6-615e-11ea-b023-8bea15c07ed6	906e7656-5d22-11ea-82b3-8bec0ac2ad97	aa22cd8e-615c-11ea-96ff-1782b564d1de	2020-03-08 17:01:31.694332+00	2020-03-08 17:01:31.694332+00
75aa822a-615e-11ea-b023-8794c38d63b4	84fb465a-5d22-11ea-82b3-1fd3eb9389c5	aa22cd8e-615c-11ea-96ff-1782b564d1de	2020-03-08 17:01:31.694332+00	2020-03-08 17:01:31.694332+00
75aa8478-615e-11ea-b023-873272f412ac	7992a470-5d22-11ea-82b3-3f05f3dd161a	aa22cd8e-615c-11ea-96ff-1782b564d1de	2020-03-08 17:01:31.694332+00	2020-03-08 17:01:31.694332+00
75aa8680-615e-11ea-b023-cb1ff55c91ff	6d9af1f4-5d22-11ea-82b3-cb2c0ef45bd4	aa22cd8e-615c-11ea-96ff-1782b564d1de	2020-03-08 17:01:31.694332+00	2020-03-08 17:01:31.694332+00
75aa8856-615e-11ea-b023-cfcc3f25c7ed	623d47ee-5d22-11ea-82b3-e3b1aa921a42	aa22cd8e-615c-11ea-96ff-1782b564d1de	2020-03-08 17:01:31.694332+00	2020-03-08 17:01:31.694332+00
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.session (sid, sess, expire) FROM stdin;
VsqRM3GJWg9KoEmiKzivmPWLLTRgUSBh	{"cookie":{"originalMaxAge":155519999999,"expires":"2025-02-05T07:35:24.640Z","secure":false,"httpOnly":true,"path":"/"},"user":"write","requests":1}	2025-02-05 07:45:39
EGqlNvgD62LWRm7iQt8C6VTGE7TvAnjc	{"cookie":{"originalMaxAge":155520000000,"expires":"2025-02-05T07:44:19.352Z","secure":false,"httpOnly":true,"path":"/"},"user":"write","requests":1}	2025-02-10 17:05:52
2ERgTOmEY1_aQqJ0EKy6jp6dQ5PbVJ0B	{"cookie":{"originalMaxAge":155520000000,"expires":"2025-02-10T16:47:28.701Z","secure":false,"httpOnly":true,"path":"/"},"user":"write","requests":1}	2025-02-10 17:01:32
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tags (id, name, "createdAt", "updatedAt") FROM stdin;
96ca9d70-615c-11ea-96ff-17ea76b94605	vega	2020-03-08 16:48:08.289191+00	2020-03-08 16:48:08.289191+00
aa22cd8e-615c-11ea-96ff-1782b564d1de	maryn	2020-03-08 16:48:40.751175+00	2020-03-08 16:48:40.751175+00
\.


--
-- Name: carpe_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.carpe_migrations_id_seq', 7, true);


--
-- Name: carpe_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.carpe_migrations_lock_index_seq', 1, true);


--
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 1, true);


--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- Name: carpe_migrations_lock carpe_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carpe_migrations_lock
    ADD CONSTRAINT carpe_migrations_lock_pkey PRIMARY KEY (index);


--
-- Name: carpe_migrations carpe_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carpe_migrations
    ADD CONSTRAINT carpe_migrations_pkey PRIMARY KEY (id);


--
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- Name: photos photos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photos
    ADD CONSTRAINT photos_pkey PRIMARY KEY (id);


--
-- Name: photos_tags photos_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photos_tags
    ADD CONSTRAINT photos_tags_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: photos_tags photos_tags_photoid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photos_tags
    ADD CONSTRAINT photos_tags_photoid_foreign FOREIGN KEY ("photoId") REFERENCES public.photos(id);


--
-- Name: photos_tags photos_tags_tagid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.photos_tags
    ADD CONSTRAINT photos_tags_tagid_foreign FOREIGN KEY ("tagId") REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

